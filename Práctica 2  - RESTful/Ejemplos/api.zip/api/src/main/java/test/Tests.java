package test;

import java.net.URI;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.Form;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriBuilder;

import org.glassfish.jersey.client.ClientConfig;

import model.Book;

public class Tests {
	public static void main(String[] args) {
	ClientConfig config = new ClientConfig();
	Client cliente = ClientBuilder.newClient(config);
	WebTarget servicio = cliente.target(getBaseURI());
	
	Book book = new Book("3", "Nuevo libro");
	Response respuesta = servicio.path("rest").path("books").path(book.getID()).
	request(MediaType.APPLICATION_XML).
	put(Entity.entity(book,MediaType.APPLICATION_XML),Response.class);
	
	// Return code para ver si book va bien
	System.out.println(respuesta.getStatus());
	// Obtener el contenido de Todos
	System.out.println(servicio.path("rest").path("books").
	request().accept(MediaType.TEXT_XML).get(String.class));
	// Obtenerlo en formato XML
	System.out.println(servicio.path("rest").path("books").
	request().accept(MediaType.APPLICATION_XML).get(String.class));
	// Obtener el objeto Book con id = 1
	Response checkDelete = servicio.path("rest").path("books/1").
	request().accept(MediaType.APPLICATION_XML).get();
	// Eliminar el Book con id = 1
	servicio.path("rest").path("books/1").request().delete();
	
	// Volver a obtener todos los objetos �Todos� pero el id = 1 se ha debido destruir
	System.out.println(servicio.path("rest").path("books").
	request().accept(MediaType.APPLICATION_XML).get(String.class));
	
	// Ahora nos crearemos un recurso Book utilizando un formulario Web
	// System.out.println("Creacion de 1 formulario");
	Form form = new Form();
	form.param("id", "4");
	form.param("resumen", "Demostracion de la biblioteca-cliente para formularios");
	Response respuesta2 = servicio.path("rest").path("books").request().
	post(Entity.entity(form,MediaType.APPLICATION_FORM_URLENCODED),Response.class);
	System.out.println("Respuesta del formulario " + respuesta2.getStatus());
	// Mostar el contenido de todos, id = 4 se ha debido de crear
	System.out.println(servicio.path("rest").path("books").request().
	accept(MediaType.APPLICATION_XML).get(String.class));
	}
	
	private static URI getBaseURI() {
		return UriBuilder.fromUri("http://localhost:8080/p2RESTful").build();
	}
}
