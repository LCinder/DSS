package dao;
import java.util.HashMap;
import java.util.Map;

import model.Book;

public enum DAO {
	INSTANCE;
	private Map<String, Book> contents = new HashMap<String, Book>();
	
	private DAO() {

		Book book = new Book("1", "Libro 1");
		book.setDescription("Descripcion Libro 1");
		contents.put("1", book);
		
		book = new Book("2", "Libro 2");
		book.setDescription("Descripcion Libro 2");
		contents.put("2", book);
	}
	
	public Map<String, Book> getModel(){
		return contents;
	}
}
