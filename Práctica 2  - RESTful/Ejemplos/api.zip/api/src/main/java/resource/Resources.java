package resource;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.Consumes;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Request;
import javax.ws.rs.core.UriInfo;

import dao.DAO;
import model.Book;

@Path("/books")
public class Resources {
	@Context
	UriInfo uriInfo;
	
	@Context
	Request request;
	
	@GET
	@Produces(MediaType.TEXT_XML)
	public List<Book> getBooksBrowser() {
		List<Book> books = new ArrayList<Book>();
		books.addAll(DAO.INSTANCE.getModel().values());
		return books;
	}
	
	@GET
	@Produces({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
	public List<Book> getBooks() {
		List<Book> books = new ArrayList<Book>();
		books.addAll(DAO.INSTANCE.getModel().values());
		return books;
	}

	@GET
	@Path("cont")
	@Produces(MediaType.TEXT_PLAIN)
	public String getCount() {
		int cont = DAO.INSTANCE.getModel().size();
		return String.valueOf(cont);
	}

	@POST
	@Produces(MediaType.TEXT_HTML)
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	public void newBook(@FormParam("id") String id,
		@FormParam("resumen") String resumen,
		@FormParam("descripcion") String descripcion,
		@Context HttpServletResponse servletResponse) throws IOException {
		Book Book = new Book(id, resumen);
		if (descripcion != null) {
			Book.setDescription(descripcion);
		}
		DAO.INSTANCE.getModel().put(id, Book);
		servletResponse.sendRedirect("../crear_Book.html");
	}

	@Path("{book}")
	public Resource getBook(@PathParam("book") String id) {
		return new Resource(uriInfo, request, id);
	}
}
