package resource;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Request;
import javax.ws.rs.core.UriInfo;

import model.Book;

@Path("/book")
public class Resource {

	public Resource(UriInfo uriInfo, Request request, String id) {
		// TODO Auto-generated constructor stub
	}

	@GET
	@Produces({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
	public Book getXML() {
		Book book = new Book();
		book.setSummary("Resumen XML");
		book.setDescription("Descripcion XML");
		return book;
	}

	@GET
	@Produces({ MediaType.TEXT_XML })
	public Book getHTML() {
		Book book = new Book();
		book.setSummary("Resumen XML");
		book.setDescription("Descripcion XML");
		return book;
	}
}