package client;


import java.net.URI;

import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.UriBuilder;

import org.glassfish.jersey.client.ClientConfig;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.api.client.config.DefaultClientConfig;

public class Test {
	public static void main(String[] args) {
		DefaultClientConfig config = new DefaultClientConfig();
		Client client = Client.create(config);
		WebResource service = client.resource(getBaseURI());
		
		System.out.print("XML Plain");
		System.out.print(service.path("rest").path("todo")
		.accept(MediaType.TEXT_XML).get(String.class));
		
		System.out.print("XML Application");
		System.out.print(service.path("rest").path("todo")
		.accept(MediaType.APPLICATION_XML).get(String.class));
	}
	
	public static URI getBaseURI() {
		return UriBuilder.fromUri("http://localhost:8080/practica2Bookshop").build();
	}
}
