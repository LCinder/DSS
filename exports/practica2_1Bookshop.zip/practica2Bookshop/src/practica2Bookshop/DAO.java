package practica2Bookshop;

import java.util.HashMap;
import java.util.Map;

import practica2Bookshop.model.Model;

public enum DAO {
	INSTANCE;
	
	private Map<String, Model> contents = new HashMap<String, Model>();
	
	private DAO() {
		Model model = new Model("1", "REST");
		model.setDescription("descripcion");
		contents.put("1", model);
		
		model = new Model("2", "DSS");
		model.setDescription("descripcion2");
		contents.put("2", model);
	}
	
	public Map<String, Model> getModel() {
		return contents;
	}
	
}
