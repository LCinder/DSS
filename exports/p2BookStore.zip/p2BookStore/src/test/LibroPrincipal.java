package test;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;

import model.Libreria;
import model.Libro;

public class LibroPrincipal {
	private static final String LIBRERIA_XML = "./libreria-jabx.xml";
	
	public static void main(String[] args) throws JAXBException, IOException{
		ArrayList<Libro> listaLibros = new ArrayList<Libro>();
		
		Libro libro1 = new Libro();
		libro1.setIsbn("978-0060554736");
		libro1.setName("El Juego");
		libro1.setAuthor("Neil Strauss");
		libro1.setEditorial("Harpercollins");
		listaLibros.add(libro1);
		
		Libro libro2 = new Libro();
		libro2.setIsbn("978-3832180577");
		libro2.setName("Zonas humedas");
		libro2.setAuthor("Charlotte Roche");
		libro2.setEditorial("Dumont Buchverlag");
		listaLibros.add(libro2);
		listaLibros.add(libro1);
		
		Libreria libreria = new Libreria();
		libreria.setName("Frankfurt Bookstore");
		libreria.setUbication("Aeropuerto de Frankfurt");
		libreria.setLibros(listaLibros);
		
		// crear el contexto JAXB e instanciar el marshaller
		JAXBContext contexto = JAXBContext.newInstance(Libreria.class);
		Marshaller m = contexto.createMarshaller();
		m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
		// Escribir en la corriente de salida: System.out
		m.marshal(libreria, System.out);
		// Escribir en File
		m.marshal(libreria, new File(LIBRERIA_XML));
		// conseguir las variables de nuestro archivo XML, que hemos creado anteriormente
		
		System.out.println();
		System.out.println("Salida desde nuestro archivo XML: ");
		Unmarshaller um = contexto.createUnmarshaller();
		Libreria libreria2 = (Libreria) um.unmarshal(new FileReader(LIBRERIA_XML));
		ArrayList<Libro> lista = libreria2.getLibros();
		for (Libro libro : lista)
			System.out.println("Libro: " + libro.getName() + " de "+ libro.getAuthor());
		
		}

}
