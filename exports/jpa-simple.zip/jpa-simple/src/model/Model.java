package model;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import model.Book;

public class Model {
	
	private static final String PERSISTENCE_UNIT_NAME = "tutorialJPA";
	private static EntityManagerFactory factory;
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		factory = Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);
		EntityManager em = factory.createEntityManager();
		// leer las entradas existentes y escribir en la consola
		Query q = em.createQuery("Select b FROM Book b");
		//Crearse una lista con template: "Completo" a la que asignameros el resultado de la consulta
		//en la base de datos ("q.getResultList()"
		//Iterar en la lista e imprimir las instancias "completo"
		//Ahora imprimimos el numero de registros que tiene ya la base de datos
		List<Book> books = q.getResultList();
		
		for (Book book: books)
			System.out.println(books);
		
		System.out.println("Size: " + books.size());
		
		//Ahora vamos a trabajar con una transaccion en la base de datos
		em.getTransaction().begin();
		//Crearse una instancia de completo y utilizar los metodos "setResumen()" y "setDescripcion()"
		Book book = new Book();
		book.setSummary("Summary");
		book.setDescription("Description");
		//Posteriormente hay que decir al gestor de entidad (em) que la instancia va a ser persistente;
		//conseguir la transaccion ("em.getTransaction()") y hacerla definitiva ("commit()")
		em.persist(book);
		em.getTransaction().commit();
		//Por ultimo, hay que cerrar al gestor de entidad
		em.close();
	}
}